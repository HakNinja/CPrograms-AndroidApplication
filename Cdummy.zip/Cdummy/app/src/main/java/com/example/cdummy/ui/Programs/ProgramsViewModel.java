package com.example.cdummy.ui.Programs;

import android.view.View;

import androidx.lifecycle.ViewModel;

public class ProgramsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}