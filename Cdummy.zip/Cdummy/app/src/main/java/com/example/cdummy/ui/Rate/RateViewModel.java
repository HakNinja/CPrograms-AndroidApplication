package com.example.cdummy.ui.Rate;

import androidx.lifecycle.ViewModel;

public class RateViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}