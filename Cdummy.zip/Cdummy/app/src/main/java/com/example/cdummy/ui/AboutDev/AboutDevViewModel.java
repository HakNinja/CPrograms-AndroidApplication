package com.example.cdummy.ui.AboutDev;

import androidx.lifecycle.ViewModel;

public class AboutDevViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}