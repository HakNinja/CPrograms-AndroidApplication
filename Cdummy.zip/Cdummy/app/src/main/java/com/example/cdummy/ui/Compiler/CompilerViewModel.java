package com.example.cdummy.ui.Compiler;

import androidx.lifecycle.ViewModel;

public class CompilerViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}