package com.example.cdummy.ui.HelpFeed;

import androidx.lifecycle.ViewModel;

public class HelpFeedViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}