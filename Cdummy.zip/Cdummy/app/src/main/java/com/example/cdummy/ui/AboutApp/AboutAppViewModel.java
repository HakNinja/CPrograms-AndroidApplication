package com.example.cdummy.ui.AboutApp;

import androidx.lifecycle.ViewModel;

public class AboutAppViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}